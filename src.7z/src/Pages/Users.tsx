import { RouteComponentProps } from '@reach/router';
import * as React from 'react';
import { TableData } from '../Components/TableData';
import { ITableHdrData, ITableRowData } from '../Components/Types/api';

interface IUsersProps extends RouteComponentProps {
    path: string;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const THeaderData: ITableHdrData[] = [
    { text: 'Ид.' },
    { text: 'Фамилия, имя, отчество' },
    { text: 'Компания' },
    { text: 'Типовая роль' },
    { text: 'Должность' },
    { text: 'Email' },
    { text: 'Логин' },
    { text: 'Пароль' },
    { text: 'Дата ввода' },
    { text: 'Дата блокировки' },
    { text: 'Действия' },
];

const TRowsData: ITableRowData[] = [
    { id: 1, text: '123' },
    { id: 2, text: 'Гуляев Олег кузьмич' },
    { id: 3, text: 'ООО "Мечел-ИнфоТех"' },
    { id: 4, text: 'Технический администратор' },
    { id: 5, text: 'Программист' },
    { id: 6, text: 'gulok@yandex.ru' },
    { id: 7, text: 'GULYAEVOK' },
    { id: 8, text: 'Gudvin48' },
    { id: 9, text: '15.03.2012' },
    { id: 10, text: '' },
    { id: 11, text: '' },
];

const Users: React.FC<IUsersProps> = () => {
    return (
        <div>
            <TableData colNames={THeaderData} dataRows={TRowsData} />;
        </div>
    );
};

export { Users };
