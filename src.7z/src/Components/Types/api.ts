export interface ITableHdrData {
    text: string;
}

export interface ITableRowData {
    id: number;
    text: string;
}
