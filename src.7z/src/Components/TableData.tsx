/* eslint-disable react/prop-types */
import * as React from 'react';
import { ITableHdrData, ITableRowData } from './Types/api';

interface ITableHeaderProps {
    colNames: ITableHdrData[];
    dataRows: ITableRowData[];
}

const TableData: React.FC<ITableHeaderProps> = props => {
    return (
        <div className="container">
            <div className="row">
                <table className="table table-bordered table-striped table-hover table-sm">
                    <thead className="table-active">
                        <tr>
                            {props.colNames.map(item => (
                                <th scope="col" key={item.text}>
                                    {item.text}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="table-active">
                        <tr>
                            {props.dataRows.map(item => (
                                <td key={item.id}>{item.text}</td>
                            ))}
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export { TableData };

