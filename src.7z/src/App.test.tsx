import { render } from '@testing-library/react';
import React from 'react';
import { RoutedApp } from './App';

test('renders learn react link', () => {
    const { getByText } = render(<RoutedApp />);
    const linkElement = getByText(/FOOTER/);
    expect(linkElement).toBeInTheDocument();
});
