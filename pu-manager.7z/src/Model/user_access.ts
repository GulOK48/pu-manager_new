export interface IUserAccessItem {
    id: number;
    user_id: number;
    company_id: number;
}