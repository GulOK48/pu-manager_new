export interface ITypicalRole {
    id: number;
    role_name: string;
}