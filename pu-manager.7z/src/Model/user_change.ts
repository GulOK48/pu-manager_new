export interface IUserChangeItem {
    id: number;
    date_change: Date;
    param_change: string;
    user_id: number;
}