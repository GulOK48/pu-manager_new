export interface IDivisionItem {
    id: number;
    division_name: string;
}