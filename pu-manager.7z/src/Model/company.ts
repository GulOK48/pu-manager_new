export interface ICompanyItem {
    id: number;
    company_name: string;
    division_id: number;
}