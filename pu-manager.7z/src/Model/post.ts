export interface IPostItem {
    id: number;
    post_name: string;
}